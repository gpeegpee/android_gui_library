v1.0.4
======

- Added setText methods to quickly set the EditText text
- Added setTextWithoutAnimation methods to set the EditText without triggering the label animation

v1.0.3
======

- Removed app icon that was conflicting with some apps
- Removed allowBackup tag
- Added support for imeOptions attributes
- Added support for custom IDs


v1.0.2
======

- Fixed focus retention on configuration change
- Better RTL support
- Removed theme from manifest
- Added AboutActivity to sample project
- Partial support for nextFocus* attributes


v1.0.1
======

- Support for additional attributes (floatLabelColor, inputType)


v1.0.0
======

Initial release

