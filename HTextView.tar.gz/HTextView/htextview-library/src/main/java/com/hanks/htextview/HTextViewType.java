package com.hanks.htextview;

/**
 * Created by hanks on 15-12-14.
 */
public enum HTextViewType {
    SCALE, EVAPORATE, FALL, PIXELATE, ANVIL, SPARKLE, LINE, TYPER, RAINBOW
}
