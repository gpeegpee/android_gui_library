package uk.co.deanwild.flowtextview.listeners;

/**
* Created by Dean on 24/06/2014.
*/
public interface OnLinkClickListener {
    public void onLinkClick(String url);
}
