package uk.co.deanwild.flowtextview.models;

/**
* Created by Dean on 24/06/2014.
*/
public class Area {
    public float x1;
    public float x2;
    public float width;
}
