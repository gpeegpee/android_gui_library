package com.github.paolorotolo.appintroexample.slides.policyDemo;

import android.graphics.Color;

public final class PolicyDemoSlide2 extends PolicyDemoSlide1 {

    @Override
    public int getDefaultBackgroundColor() {
        return Color.parseColor("#2196F3");
    }
}
