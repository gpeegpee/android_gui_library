package com.github.paolorotolo.appintroexample.slides.policyDemo;

import android.graphics.Color;

public final class PolicyDemoSlide3 extends PolicyDemoSlide1 {

    @Override
    public int getDefaultBackgroundColor() {
        return Color.parseColor("#FF9800");
    }
}
