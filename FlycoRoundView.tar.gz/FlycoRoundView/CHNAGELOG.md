#Change Log
Version 1.1.0 *(2015-11-24)*
----------------------------
* change the realization of RoundView without ondraw since press effect is not very good in some devices.
  
Version 1.1.2 *(2015-12-7)*
----------------------------
* remove method update() in RoundViewDelegate.  

Version 1.1.2 *(2015-12-9)*
----------------------------
* new added attr rv_isRippleEnable only useful for API21+
  


