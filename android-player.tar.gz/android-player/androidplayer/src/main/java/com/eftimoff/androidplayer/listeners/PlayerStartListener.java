package com.eftimoff.androidplayer.listeners;

/**
 * When the player starts.
 * <p/>
 * Created by georgi.eftimov on 4/16/2015.
 */
public interface PlayerStartListener {

    void onStart();
}
