package com.eftimoff.androidplayer.listeners;

/**
 * When the player ends.
 * <p/>
 * Created by georgi.eftimov on 4/16/2015.
 */
public interface PlayerEndListener {

    void onEnd();
}
