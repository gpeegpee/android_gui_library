package com.github.jlmd.animatedcircleloadingview.exception;

/**
 * @author jlmd
 */
public class NullStateListenerException extends RuntimeException {
  // Empty
}
