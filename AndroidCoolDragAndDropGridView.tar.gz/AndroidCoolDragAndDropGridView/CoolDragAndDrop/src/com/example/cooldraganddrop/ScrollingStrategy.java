package com.example.cooldraganddrop;

public interface ScrollingStrategy {

	boolean performScrolling(final int x, final int y, final CoolDragAndDropGridView view);

}
