CoolDragAndDrop
===============

An example of a gridview with various column span items with drag and drop support like Google keep has :

![alt tag](https://drive.google.com/uc?export=download&id=0B4jPPQOZ8N-MUllGZmV3X2ZpMjg)
