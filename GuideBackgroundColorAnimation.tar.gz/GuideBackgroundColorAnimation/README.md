ALLforYOU _android_ _UI_ _design_
========================
5/21/2014 13:45:07 PM 

> 引言
 
	实现了滑动Viewpager的时候，背景动态变化的效果. IDE :Android Studio



>  效果图


<img src="https://raw.githubusercontent.com/TaurusXi/GuideBackgroundColorAnimation/master/art/sample.gif"/>
> 关注我

 关注我的微博：习成_myxilove

> License
Copyright 2013 Issac Wong
Copyright 2013 Kenefe_Li
Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with the License. You may obtain a copy of the License at
 http://www.apache.org/licenses/LICENSE-2.0
Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.
